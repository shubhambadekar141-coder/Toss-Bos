const canvas=document.getElementById('c');const ctx=canvas.getContext('2d');let DPR=devicePixelRatio||1;
function resize(){canvas.width=Math.floor(canvas.clientWidth*DPR);canvas.height=Math.floor(canvas.clientHeight*DPR);ctx.scale(DPR,DPR)}
resize();window.addEventListener('resize',()=>{DPR=devicePixelRatio||1;resize()})
let player={x:40,y:400,vy:0,w:50,h:50,onGround:true,skin:'bird1'};let gravity=0.9,jumpPower=-16;let score=0,running=true,coins=0;
function reset(){player.y=400;player.vy=0;score=0;coins=0;running=true;document.getElementById('msg').textContent='Boss Toss • Tap to fly';document.getElementById('restart').classList.add('hidden')}
document.getElementById('restart').addEventListener('click',()=>{reset()})
function jump(){if(player.onGround){player.vy=jumpPower;player.onGround=false}}
canvas.addEventListener('touchstart',(e)=>{e.preventDefault();jump()},{passive:false});canvas.addEventListener('mousedown',(e)=>{jump()});
function update(){if(!running)return;player.vy+=gravity;player.y+=player.vy;if(player.y+player.h>=450){player.y=450-player.h;player.vy=0;player.onGround=true}}
function draw(){ctx.clearRect(0,0,canvas.width/DPR,canvas.height/DPR);ctx.fillStyle='#228B22';ctx.fillRect(0,450,canvas.width/DPR,canvas.height/DPR-450);ctx.fillStyle='#f97316';ctx.fillRect(player.x,player.y,player.w,player.h)}
function loop(){update();draw();requestAnimationFrame(loop)}
loop()
