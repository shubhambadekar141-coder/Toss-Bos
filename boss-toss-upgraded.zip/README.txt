Boss Toss Upgraded Game (Cartoon Version)

Features:
- Cartoon birds with human rider
- Unlockable skins: dragon, unicorn
- Collectible coins
- Shop to buy skins
- Safe bird hurt sounds, flap sounds, coin sounds
- Mobile-ready HTML5 game (use PWA2APK or Kodular to make APK)
